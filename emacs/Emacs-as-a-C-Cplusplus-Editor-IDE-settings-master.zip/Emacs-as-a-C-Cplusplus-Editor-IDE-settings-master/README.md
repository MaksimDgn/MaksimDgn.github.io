Emacs-as-a-C-Cplusplus-Editor-IDE-settings
==========================================

.emacs file for "Emacs as a C/C++ Editor/IDE" video tutorial series

This is the .emacs file we build in "Emacs as a C/C++ Editor/IDE" series: https://www.youtube.com/playlist?list=PL-mFLc7R_MJet8ItKipCtYc7PWoS5KTfM

Happy coding with Emacs :)

Baris Yuksel
